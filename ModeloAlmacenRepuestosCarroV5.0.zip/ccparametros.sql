-- creacion cc parametros
-- creado por:Jose de Jesus Aguirre
-- fecha creacion: 02/09/2014

-- modificado por:

-- fecha modificacion:

-- descripcion:


alter table parametros add(
    constraint PAR_PK_ID primary key (ID)
);