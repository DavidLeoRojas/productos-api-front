-- creacion tabla periodos
-- creado por:Jose de Jesus Aguirre
-- fecha creacion: 02/09/2014

-- modificado por:

-- fecha modificacion:

-- descripcion:


create table PERIODOS(
   ID	                NUMBER(3)            not null,
   MES                  NUMBER(2)            not null,
   ANIO                 NUMBER(4)            not null
);