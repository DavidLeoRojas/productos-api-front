-- creacion tabla MARCAS
-- creado por:Jose de Jesus Aguirre
-- fecha creacion: 02/09/2014

-- modificado por:

-- fecha modificacion:

-- descripcion:

create table MARCAS(
   ID_MARCA             NUMBER(6)            not null,
   NOMBRE_MARCA         VARCHAR2(20)         not null
 );

