-- creacion tabla parametros
-- creado por:Jose de Jesus Aguirre
-- fecha creacion: 02/09/2014

-- modificado por:

-- fecha modificacion:

-- descripcion:


create table PARAMETROS(
   ID		         NUMBER(3)            not null,
   NOMBRE                varchar2(15)         not null,
   VALOR	         NUMBER(10,2)         not null
);