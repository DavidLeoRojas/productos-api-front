create table PROVEEDORES(
   CODIGO     NUMBER(6)            not null,
   NOMBRE     VARCHAR2(20)         not null,
   TELEFONO   NUMBER(6)            not null
);