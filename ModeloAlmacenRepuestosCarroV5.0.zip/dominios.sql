NOMBRE DOMINIOS          VALORES                                   TABLAS 
---------------- -------------------------------------------- ----------------    
genero =         {'F'=femenino, 'M'=masculino}			(EMPLEADO)
tipo_lugar =     {'P'=pais, 'D'=departamento, 'M'=municipio}	(LUGAR)
estado =         {'A'=activo, 'I'=inactivo, 'D'=deudor}		(CLIENTE)
forma_pago =     {'C'=contado, 'P'=pago}			(FACTURA)
tipo_concepto =  {'P'=pago, 'D'=descuento}			(CONCEPTO)
obligatoriedad = {'O'=opcional, 'M'=mandatorio}			(CONCEPTO)