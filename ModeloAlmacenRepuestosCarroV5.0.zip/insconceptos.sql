insert into conceptos  values (20,'SALARIO','M','P',NULL);
insert into conceptos  values (21,'PENSION','M','D',0.04);
insert into conceptos  values (22,'HORAS EXTRAS NOCTURNO','O','P',1.75);
insert into conceptos  values (23,'AUXILIO TRANSPORTE','O','P',0.11);
insert into conceptos  values (24,'HORAS EXTRAS DIURNO','O','P',1.25);
insert into conceptos  values (25,'BONIFICACION','O','P',NULL);
insert into conceptos  values (27,'HORAS EXTRAS DOMINICALES','O','P',1.75);
insert into conceptos  values (28,'SALUD','M','D',0.04);
