insert into proveedores  values (750,'MOBIL',754625);
insert into proveedores  values (751,'HAVOLINE',78566);
insert into proveedores  values (752,'BRIDGESTONE',58454);
insert into proveedores  values (753,'SPARCO',52161);
insert into proveedores  values (754,'BREMBO',88422);
insert into proveedores values (756,'PRACO DIDACOL', 23452);
insert into proveedores  values (755,'BBS',545422);