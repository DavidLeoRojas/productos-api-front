drop table detalles cascade constraints;
drop table libranzas cascade constraints;
drop table nomina cascade constraints;
drop table cartera cascade constraints;
drop table ventas cascade constraints;
drop table facturas cascade constraints;
drop table directorio cascade constraints;
drop table productos cascade constraints;
drop table marcas cascade constraints;
drop table conceptos cascade constraints;
drop table proveedores cascade constraints;
drop table contratos cascade constraints;
drop table empleados cascade constraints;
drop table clientes cascade constraints;
drop table periodos cascade constraints;
drop table parametros cascade constraints;
drop table lugares cascade constraints;
purge recyclebin;


















