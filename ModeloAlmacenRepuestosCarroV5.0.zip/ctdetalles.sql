-- creacion tabla detalle
-- creado por:Jose de Jesus Aguirre
-- fecha creacion: 02/09/2014

-- modificado por:

-- fecha modificacion:

-- descripcion:

create table DETALLES(
   LIBRANZA          NUMBER(3)            not null,
   PERIODO           NUMBER(3)            not null,
   VALOR             NUMBER(10,2)
 );
