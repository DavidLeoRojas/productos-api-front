-- creacion cc MARCAS
-- creado por:Jose de Jesus Aguirre
-- fecha creacion: 02/09/2014

-- modificado por:

-- fecha modificacion:

-- descripcion:

alter table MARCAS ADD(
    constraint PK_MARCA primary key (ID_MARCA)
);