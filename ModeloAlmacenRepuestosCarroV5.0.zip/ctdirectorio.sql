create table DIRECTORIO(
   ID_PRODUCTO          NUMBER(6)            not null,
   CODIGO               NUMBER(6)            not null
);