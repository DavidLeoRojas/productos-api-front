create table CONTRATOS (
ID_CONTRATO          NUMBER(4)            not null,
CEDULA               NUMBER(4)            not null,
FECHA_INICIO         DATE                 not null,
FECHA_FIN            DATE,
SALARIO              NUMBER(8)            not null,
COMISION             NUMBER(4)          not null   
);
