-- modificacion de la tabla periodos
-- creado por:Jos� aguirre
-- fecha creacion: 02/09/2014

-- modificado por:

-- fecha modificacion:

-- descripcion:


alter table PERIODOS ADD(
constraint PERIODO_PK_ID primary key (ID)
);