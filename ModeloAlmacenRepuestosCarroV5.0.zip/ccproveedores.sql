alter table proveedores add(
CONSTRAINT prov_pk_codigo PRIMARY KEY (codigo)
);