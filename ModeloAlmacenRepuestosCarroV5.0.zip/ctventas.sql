--Autores: Jonathan Giovanny Camargo Sanabria, Harold Noah Parra Gonzalez
--Fecha: 
--Tabla: Ventas
create table VENTAS 
(
   ID    	NUMBER(6)     not null,
   NUMERO       NUMBER(6)     not null,
   CANTIDAD     NUMBER(3)     not null,
   VALOR 	NUMBER(6)     not null
);