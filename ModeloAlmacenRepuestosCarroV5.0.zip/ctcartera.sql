create table CARTERA 
(
   NUMERO_FACTURA      	NUMBER(6)            	not null,
   CUOTA                NUMBER(2)               not null,
   FECHA_PAGO         	DATE            	not null,
   VALOR           	NUMBER(6)            	not null
);